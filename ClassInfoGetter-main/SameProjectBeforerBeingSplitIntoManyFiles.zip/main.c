
#include <stdio.h>
#include <stdlib.h>
#include "program.h"

void print(ClassesStruct class)
{
    printf("%-35s %-11s %-25s %-3d %-5s %s", class.className, class.classNumber,class.professor, class.seats, class.days, class.time);
    return;
}

void userInputHandler(ClassesStruct myArray[], int num)
{
    char userInput;
    char nl;
    char input[70];

    while(userInput != 'q')
    {
        printf("Choices: \n");
        printf("n - print class given number \n");
        printf("d - print all classes for a given day combo \n");
        printf("p - print all classes for a given professor \n");
        printf("q - quit \n");
        scanf(" %c%c", &userInput, &nl);

        if (userInput == 'n')
        {
            printf("Enter class number: ");
            scanf("%[^\n]", input);
            for (int i = 0; i < num; i++)
            {
                if (strncmp(myArray[i].classNumber, input, strlen(input)) == 0)
                {
                    print(myArray[i]);
                }

            }
        }

        else if (userInput == 'd')
        {
            printf("Enter class days to print (MWF or TR): ");
            scanf("%s", input);
            printf("List of classes for %s: \n", input);
            for (int i = 0; i < num; i++)
            {
                if (strncmp(myArray[i].days, input, 3) == 0)
                {
                    print(myArray[i]);
                }
            }
        }

        else if(userInput == 'p')
        {
            printf("Enter Professor's Last Name: ");
            scanf("%s", input);
            printf("List of classes for Professor %s: \n", input);
            for (int i = 0; i < num; i++)
            {
                if (strncmp(myArray[i].professor, input, strlen(input)) == 0)
                {
                    print(myArray[i]);
                }

            }

        }
    }

    return;
}

int readin(ClassesStruct myArray[])
{
    FILE* inpFile = fopen("/public/pgm1/classes.csv", "r");

    if (inpFile == NULL)
    {
        printf("Error opening file");
    }

    int i = 0;
    char* delim = ",";
    char line[100];
    char *datetime;

    while(fgets(line, 100, inpFile) != NULL)
    {
        strcpy(myArray[i].classNumber, strtok(line, delim));
        strcpy(myArray[i].className, strtok(NULL, delim));
        strtok(NULL, delim);
        myArray[i].seats = atoi(strtok(NULL, delim));
        strtok(NULL, delim);
        strtok(NULL, delim);
        strcpy(myArray[i].professor, strtok(NULL, delim));
        datetime = strtok(NULL, delim);
        strcpy(myArray[i].days, strtok(datetime, " "));
        strcpy(myArray[i].time, strtok(NULL, " "));
        i++;
    }
    fclose(inpFile);
    return i;
}
int main()
{
    int numClasses;                             //initializes a int for class numbers
    ClassesStruct classes[30];                  //Creates "array of structs that stores all the data for the classes"
    numClasses = readin(classes);               //reads in class data and passes struct array
    userInputHandler(classes, numClasses);      //passes struct array and number of classes to choice
    return(0);                                  //retursn
}