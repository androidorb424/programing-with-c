#include <vector>
#include <iostream>
#include "employee.h"   //"5 points – put each class in a separate header and source file (.cpp)(for the class methods
using namespace std;


//#################################
int main()
{
    Employee employee;

    employee.readEmployee();
    cout << employee.getVect()[0].getFname() << " " << employee.getVect()[0].getLname();


    return 0;
}