#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iostream>

using namespace std;


void readUniv() {    //UnivClass:: links this to the header file
//    vector<UnivClass> uniVect;
    int num;        //This is for string to int conversions.
    string fileName = "C:\\Users\\captl\\CLionProjects\\Week14\\classes.csv";
    vector<vector<string>> content;     //holds rows
    vector<string> row;                 //csv rows
    string line, word;

    fstream file (fileName, ios::in);   //reads csv file into above vectors
    if(file.is_open()) {
        while(getline(file,line)) {
            row.clear();
            stringstream str(line);
            while(getline(str,word,',')) {
                row.push_back(word);
            }
            content.push_back(row); //remove
        }
    }
    else {      //lets me know I didn't find the file
        cout << "Could not find the file";
    }

    for (int i = 0; i < content.size(); i++) {      //parses through the vectors and makes a class with the information from each row
        cout << content[i][0] << "\n";
    }
}




int main()
{
    readUniv();

    return 0;
}