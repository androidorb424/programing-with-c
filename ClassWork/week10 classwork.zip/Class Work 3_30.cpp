#include <iostream>
#include <cmath>
#include <vector>
using namespace std;

void error(string s) 
{
    throw runtime_error("Error: " + s);
}

int main(int a, char** b) 
{
       

    if (a != 2) { //if no number is given
        error("Number not on command line.");
    }
    int userInput = atoi(b[1]); 
    
    
    cout << "Number " << userInput << " is written as " << userInput*2;

   

    return 0;
}