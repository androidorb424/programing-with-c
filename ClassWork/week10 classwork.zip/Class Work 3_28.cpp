#include <iostream>
#include <cmath>
#include <vector>
using namespace std;



int main() {

    bool loop = true;
    int x;
    vector<int> inputs;
    int sum = 0;
    
    do{
        cout << "Type a number: ";
        cin >> x;
        if (x == 0){
            break;
        }
        inputs.push_back(x);
    }
    while (loop == true);

    while (!inputs.empty()) { //loops through vector to print out 
        inputs.back();
        sum += inputs.back();
        inputs.pop_back();
    }   
    
    cout << "The sum of your imputs is : " << sum;



    return 0;
}