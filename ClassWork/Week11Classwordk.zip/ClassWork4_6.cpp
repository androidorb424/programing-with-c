#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;
using namespace std;




class Name {
public:
    string name;
    void set_name(string a) {
        name = a;
    }
    string get_name() {
        return name;
    }
};

class Age {
public:
    int age;
    void set_age(int a) {
        age = a;
    }
    int get_age() {
        return age;
    }
};
class NameAndAge {
public:
    Name name;
    Age age;
    NameAndAge(){
        
    }
    NameAndAge(string a, int b) {
        name.set_name(a);
        age.set_age(b);
    }
    void setName(string a){
        name.set_name(a);;
    }
    void setAge(int a){
        age.set_age(a);
    }
    string getName(){
        return name.get_name();
    }
    int getAge(){
        return age.get_age();
    }

};
// bool compareFunction (string a, string b) {
//     return a<b;
// } 

int main()
{
    vector<NameAndAge> vect; 
    string n;
    int a;
    

    for (int i=1;i<5;i++){
        cout << "Enter a name: ";
        cin >> n;
        cout << "Enter an age";
        cin >> a;
        NameAndAge NandA(n,a);
        vect.push_back(NandA);
    }
    //sort(vect.begin(),vect.end(),compareFunction);
    for(int j = 0; j < vect.size(); j++){   //loops through vecter finding like exponents for addition
        cout << "name and age : " << vect[j].getName() << " " << vect[j].getAge() << "\n";
    }
    
    
    
    return 0;
}
