#include <stdio.h>
#include <iostream>
#include <vector>
using namespace std;
using namespace std;




class Name {
public:
    string name;
    void set_name(string a) {
        name = a;
    }
    string get_name() {
        return name;
    }
};

class Age {
public:
    int age;
    void set_age(int a) {
        age = a;
    }
    int get_age() {
        return age;
    }
};
class NameAndAge {
public:
    Name name;
    Age age;
    NameAndAge(){
        
    }
    NameAndAge(string a, int b) {
        name.set_name(a);
        age.set_age(b);
    }
    void setName(string a){
        name.set_name(a);;
    }
    void setAge(int a){
        age.set_age(a);
    }
    string getName(){
        return name.get_name();
    }
    int getAge(){
        return age.get_age();
    }

};


int main()
{
    NameAndAge NandA;
    NandA.setName("John");
    NandA.setAge(21);

    NameAndAge NandA2("Jim",20);
    
    cout << "name and age 1: " << NandA.getName() << " " << NandA.getAge() << "\n";
    cout << "name and age 2: " << NandA2.getName() << " " << NandA2.getAge() << "\n";
    
    return 0;
}
