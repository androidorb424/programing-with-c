#include <iostream>
using namespace std;

int main() {
    string firstName;
    string lastName;
    int age;
    cout << "Type your first name: ";
    cin >> firstName; // get user input from the keyboard
    cout << "Type your last name: ";
    cin >> lastName; // get user input from the keyboard
    cout << "Type your age: ";
    cin >> age; // get user input from the keyboard
    cout << "Your name is: " << firstName << " " << lastName << "\n";
    cout << age << " years old is a wonderful age";
    return 0;
}
